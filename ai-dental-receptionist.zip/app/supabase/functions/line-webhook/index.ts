// Supabase Edge Function: line-webhook
//
// Handles incoming LINE Messaging API webhook events.
//
// Setup in LINE Developers Console > Messaging API:
//   Webhook URL: https://<project-ref>.functions.supabase.co/line-webhook
//   Use webhook: enabled
//
// Required env vars:
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
//
// Note on multi-tenant signature verification:
// LINE signs the payload with each channel's own Channel Secret, and the
// webhook body includes a `destination` field (the bot's userId), which we
// store in channel_configs.line_channel_id at setup time. We look up the
// config by `destination` first, then verify the signature using that
// clinic's channel secret. If verification fails, we reject the request.

import { getChannelConfigByDestination, replyToLine, verifyLineSignature } from "../_shared/line.ts";
import { getOrCreateConversation } from "../_shared/conversations.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const FUNCTIONS_URL = `${SUPABASE_URL}/functions/v1`;

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const rawBody = await req.text();
  const signature = req.headers.get("x-line-signature");

  let payload: any;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return new Response("Invalid JSON", { status: 400 });
  }

  const destination = payload.destination;
  if (!destination) {
    return new Response("Missing destination", { status: 400 });
  }

  const config = await getChannelConfigByDestination(destination);
  if (!config) {
    console.error("No clinic configured for LINE destination:", destination);
    // Return 200 so LINE doesn't retry indefinitely for a misconfigured/removed bot
    return new Response("OK", { status: 200 });
  }

  const valid = await verifyLineSignature(rawBody, signature, config.line_channel_secret);
  if (!valid) {
    console.error("Invalid LINE webhook signature");
    return new Response("Invalid signature", { status: 401 });
  }

  // Respond 200 quickly; process events inline (Edge Functions tolerate
  // this for normal volumes — move to a queue for high throughput).
  try {
    for (const event of payload.events || []) {
      await handleEvent(config, event);
    }
  } catch (e) {
    console.error("Error processing LINE webhook:", e);
  }

  return new Response("OK", { status: 200 });
});

async function handleEvent(config: any, event: any) {
  if (event.type !== "message") return; // ignore follow/unfollow/postback for now
  if (event.message?.type !== "text") {
    await replyToLine(
      config,
      event.replyToken,
      "Sorry, I can only read text messages right now. Could you type your question?"
    );
    return;
  }

  const userId = event.source?.userId;
  const text = event.message.text;

  if (!userId || !text) return;

  const { data: conversation, error: convError } = await getOrCreateConversation({
    clinicId: config.clinic_id,
    channel: "line",
    channelUserId: userId,
  });

  if (convError || !conversation) {
    console.error("Failed to get/create conversation:", convError);
    await replyToLine(config, event.replyToken, "Sorry, something went wrong. Please try again shortly.");
    return;
  }

  const engineRes = await fetch(`${FUNCTIONS_URL}/conversation-engine`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
    },
    body: JSON.stringify({
      clinic_id: config.clinic_id,
      conversation_id: conversation.id,
      message: text,
    }),
  });

  if (!engineRes.ok) {
    console.error("conversation-engine call failed:", await engineRes.text());
    await replyToLine(
      config,
      event.replyToken,
      "Sorry, I'm having trouble right now. Please try again or call the clinic directly."
    );
    return;
  }

  const data = await engineRes.json();
  await replyToLine(config, event.replyToken, data.reply);
}

// Supabase Edge Function: process-followups
//
// Run on a schedule (every ~15 min via pg_cron). Each run does two passes:
//
// 1. SCHEDULE: scan appointments and create `follow_ups` rows that don't
//    exist yet (idempotent via the unique (appointment_id, type) constraint).
//      - appointment_reminder_24h: confirmed appointments ~24h out
//      - appointment_reminder_2h: confirmed appointments ~2h out (if enabled)
//      - booking_no_response: 'requested' appointments older than
//        no_response_followup_hours with no status change (nudges staff
//        AND optionally the patient)
//
// 2. SEND: find `follow_ups` rows with status='pending' and
//    scheduled_for <= now(), send via the patient's channel, mark sent/failed.
//
// Required env vars: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
// (WhatsApp/LINE secrets are read by the shared send helpers as needed)

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { sendProactiveMessage } from "../_shared/notify.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

Deno.serve(async (_req) => {
  try {
    const scheduled = await scheduleFollowUps();
    const sent = await sendDueFollowUps();

    return new Response(JSON.stringify({ scheduled, sent }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("process-followups error:", err);
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});

// ---------------------------------------------------------
// Pass 1: schedule new follow-ups
// ---------------------------------------------------------
async function scheduleFollowUps() {
  const results = { reminder_24h: 0, reminder_2h: 0, no_response: 0 };

  const { data: clinics, error } = await supabase
    .from("clinic_settings")
    .select(
      "id, timezone, followups_enabled, reminder_24h_enabled, reminder_2h_enabled, no_response_followup_enabled, no_response_followup_hours"
    )
    .eq("followups_enabled", true);

  if (error) {
    console.error("Failed to load clinics:", error);
    return results;
  }

  for (const clinic of clinics || []) {
    // --- Confirmed appointments needing reminders ---
    const { data: confirmedAppts } = await supabase
      .from("appointments")
      .select("id, patient_id, preferred_date, preferred_time")
      .eq("clinic_id", clinic.id)
      .eq("status", "confirmed")
      .not("preferred_date", "is", null)
      .gte("preferred_date", toDateString(new Date()));

    for (const appt of confirmedAppts || []) {
      const apptDateTime = combineDateTime(appt.preferred_date, appt.preferred_time);
      const apptTime = new Date(apptDateTime).getTime();
      const now = Date.now();

      if (clinic.reminder_24h_enabled) {
        const sendAt = new Date(apptTime - 24 * 60 * 60 * 1000);
        if (sendAt.getTime() > now) {
          const { error: insertError } = await supabase.from("follow_ups").insert({
            clinic_id: clinic.id,
            appointment_id: appt.id,
            patient_id: appt.patient_id,
            type: "appointment_reminder_24h",
            channel: "auto",
            status: "pending",
            scheduled_for: sendAt.toISOString(),
          });
          if (!insertError) results.reminder_24h++;
          // Ignore unique constraint violations (already scheduled)
        }
      }

      if (clinic.reminder_2h_enabled) {
        const sendAt = new Date(apptTime - 2 * 60 * 60 * 1000);
        if (sendAt.getTime() > now) {
          const { error: insertError } = await supabase.from("follow_ups").insert({
            clinic_id: clinic.id,
            appointment_id: appt.id,
            patient_id: appt.patient_id,
            type: "appointment_reminder_2h",
            channel: "auto",
            status: "pending",
            scheduled_for: sendAt.toISOString(),
          });
          if (!insertError) results.reminder_2h++;
        }
      }
    }

    // --- Requested appointments with no staff response ---
    if (clinic.no_response_followup_enabled) {
      const cutoff = new Date(Date.now() - clinic.no_response_followup_hours * 60 * 60 * 1000);

      const { data: staleRequests } = await supabase
        .from("appointments")
        .select("id, patient_id, created_at")
        .eq("clinic_id", clinic.id)
        .eq("status", "requested")
        .lte("created_at", cutoff.toISOString());

      for (const appt of staleRequests || []) {
        const { error: insertError } = await supabase.from("follow_ups").insert({
          clinic_id: clinic.id,
          appointment_id: appt.id,
          patient_id: appt.patient_id,
          type: "booking_no_response",
          channel: "auto",
          status: "pending",
          scheduled_for: new Date().toISOString(),
        });
        if (!insertError) results.no_response++;
      }
    }
  }

  return results;
}

// ---------------------------------------------------------
// Pass 2: send due follow-ups
// ---------------------------------------------------------
async function sendDueFollowUps() {
  const results = { sent: 0, failed: 0, skipped: 0 };

  const { data: due, error } = await supabase
    .from("follow_ups")
    .select("*, appointments(reason, preferred_date, preferred_time, status), clinic_settings(name, phone)")
    .eq("status", "pending")
    .lte("scheduled_for", new Date().toISOString())
    .limit(50);

  if (error) {
    console.error("Failed to load due follow-ups:", error);
    return results;
  }

  for (const followUp of due || []) {
    const appt = followUp.appointments;
    const clinic = followUp.clinic_settings;

    // If the appointment was cancelled or already completed, skip silently
    if (appt && ["cancelled", "no_show", "completed"].includes(appt.status) && followUp.type !== "booking_no_response") {
      await supabase.from("follow_ups").update({ status: "skipped" }).eq("id", followUp.id);
      results.skipped++;
      continue;
    }
    // For no_response type, skip if it's no longer 'requested'
    if (followUp.type === "booking_no_response" && appt?.status !== "requested") {
      await supabase.from("follow_ups").update({ status: "skipped" }).eq("id", followUp.id);
      results.skipped++;
      continue;
    }

    const text = buildMessage(followUp.type, clinic, appt);

    const result = await sendProactiveMessage(followUp.clinic_id, followUp.patient_id, text);

    if (result.sent) {
      await supabase
        .from("follow_ups")
        .update({ status: "sent", sent_at: new Date().toISOString() })
        .eq("id", followUp.id);
      results.sent++;
    } else {
      await supabase
        .from("follow_ups")
        .update({ status: "failed", error: result.reason })
        .eq("id", followUp.id);
      results.failed++;
    }
  }

  return results;
}

function buildMessage(type: string, clinic: any, appt: any): string {
  const clinicName = clinic?.name || "the clinic";
  const dateStr = appt?.preferred_date || "your appointment date";
  const timeStr = appt?.preferred_time?.slice(0, 5) || "";

  switch (type) {
    case "appointment_reminder_24h":
      return `Hi! This is a reminder from ${clinicName} that you have an appointment tomorrow (${dateStr}${timeStr ? ` at ${timeStr}` : ""}) for ${appt?.reason || "your visit"}. Reply here if you need to reschedule.`;

    case "appointment_reminder_2h":
      return `Reminder: your appointment at ${clinicName} is coming up today at ${timeStr || "the scheduled time"}. See you soon!`;

    case "booking_no_response":
      return `Hi! Just checking in on your appointment request at ${clinicName} for ${appt?.reason || "your visit"} on ${dateStr}${timeStr ? ` at ${timeStr}` : ""}. Our team will confirm shortly — let us know if anything has changed or if you'd like a different time.`;

    default:
      return `This is a message from ${clinicName}.`;
  }
}

function toDateString(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function combineDateTime(date: string, time: string | null): string {
  const t = time || "09:00:00";
  return `${date}T${t}`;
}

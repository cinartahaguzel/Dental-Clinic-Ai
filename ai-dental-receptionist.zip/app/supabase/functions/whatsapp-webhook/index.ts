// Supabase Edge Function: whatsapp-webhook
//
// Handles both:
//   - GET: webhook verification handshake from Meta
//   - POST: incoming message events
//
// Setup in Meta App Dashboard > WhatsApp > Configuration:
//   Callback URL: https://<project-ref>.functions.supabase.co/whatsapp-webhook
//   Verify token: must match channel_configs.whatsapp_verify_token for the
//                 relevant clinic — see note below on per-clinic verify
//                 tokens vs a shared app-level token.
//
// Required env vars:
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
//   WHATSAPP_APP_SECRET   (Meta App secret, used to verify signatures)
//   WHATSAPP_VERIFY_TOKEN (shared verify token for the GET handshake;
//                          simplest setup — one Meta App per deployment)

import {
  getChannelConfigByPhoneNumberId,
  sendWhatsAppMessage,
  markWhatsAppMessageRead,
  verifyWhatsAppSignature,
} from "../_shared/whatsapp.ts";
import { getOrCreateConversation } from "../_shared/conversations.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const WHATSAPP_APP_SECRET = Deno.env.get("WHATSAPP_APP_SECRET")!;
const WHATSAPP_VERIFY_TOKEN = Deno.env.get("WHATSAPP_VERIFY_TOKEN")!;
const FUNCTIONS_URL = `${SUPABASE_URL}/functions/v1`;

Deno.serve(async (req) => {
  // -----------------------------------------------------
  // GET: webhook verification handshake
  // -----------------------------------------------------
  if (req.method === "GET") {
    const url = new URL(req.url);
    const mode = url.searchParams.get("hub.mode");
    const token = url.searchParams.get("hub.verify_token");
    const challenge = url.searchParams.get("hub.challenge");

    if (mode === "subscribe" && token === WHATSAPP_VERIFY_TOKEN) {
      return new Response(challenge, { status: 200 });
    }
    return new Response("Forbidden", { status: 403 });
  }

  // -----------------------------------------------------
  // POST: incoming message/event
  // -----------------------------------------------------
  if (req.method === "POST") {
    const rawBody = await req.text();

    // Verify signature
    const signature = req.headers.get("x-hub-signature-256");
    const valid = await verifyWhatsAppSignature(rawBody, signature, WHATSAPP_APP_SECRET);
    if (!valid) {
      console.error("Invalid WhatsApp webhook signature");
      return new Response("Invalid signature", { status: 401 });
    }

    let payload: any;
    try {
      payload = JSON.parse(rawBody);
    } catch {
      return new Response("Invalid JSON", { status: 400 });
    }

    // Always respond 200 quickly to avoid Meta retries; process inline
    // since Edge Functions can run for a reasonable duration. For higher
    // volume, push to a queue instead.
    try {
      await processWebhookPayload(payload);
    } catch (e) {
      console.error("Error processing WhatsApp webhook:", e);
    }

    return new Response("OK", { status: 200 });
  }

  return new Response("Method not allowed", { status: 405 });
});

async function processWebhookPayload(payload: any) {
  const entries = payload.entry || [];

  for (const entry of entries) {
    for (const change of entry.changes || []) {
      const value = change.value;
      if (!value?.messages) continue; // skip status updates, etc.

      const phoneNumberId = value.metadata?.phone_number_id;
      const config = await getChannelConfigByPhoneNumberId(phoneNumberId);

      if (!config) {
        console.error("No clinic configured for WhatsApp phone_number_id:", phoneNumberId);
        continue;
      }

      for (const message of value.messages) {
        await handleIncomingMessage(config, message);
      }
    }
  }
}

async function handleIncomingMessage(config: any, message: any) {
  const from = message.from; // WhatsApp user id (phone number, no +)
  const messageType = message.type;

  // Only handle text messages for now; acknowledge others politely.
  let text: string | null = null;
  if (messageType === "text") {
    text = message.text?.body;
  } else if (messageType === "interactive") {
    text =
      message.interactive?.button_reply?.title ||
      message.interactive?.list_reply?.title ||
      null;
  }

  // Mark as read
  await markWhatsAppMessageRead(config, message.id);

  if (!text) {
    await sendWhatsAppMessage(
      config,
      from,
      "Sorry, I can only read text messages right now. Could you type your question?"
    );
    return;
  }

  // Get or create the conversation for this WhatsApp user
  const { data: conversation, error: convError } = await getOrCreateConversation({
    clinicId: config.clinic_id,
    channel: "whatsapp",
    channelUserId: from,
  });

  if (convError || !conversation) {
    console.error("Failed to get/create conversation:", convError);
    await sendWhatsAppMessage(config, from, "Sorry, something went wrong. Please try again shortly.");
    return;
  }

  // Call the conversation engine
  const engineRes = await fetch(`${FUNCTIONS_URL}/conversation-engine`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
    },
    body: JSON.stringify({
      clinic_id: config.clinic_id,
      conversation_id: conversation.id,
      message: text,
    }),
  });

  if (!engineRes.ok) {
    console.error("conversation-engine call failed:", await engineRes.text());
    await sendWhatsAppMessage(
      config,
      from,
      "Sorry, I'm having trouble right now. Please try again or call the clinic directly."
    );
    return;
  }

  const data = await engineRes.json();
  await sendWhatsAppMessage(config, from, data.reply);
}

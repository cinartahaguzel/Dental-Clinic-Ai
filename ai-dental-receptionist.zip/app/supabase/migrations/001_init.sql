-- =========================================================
-- Bright Smile Dental Clinic — Supabase schema
-- =========================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------
-- clinic_settings
-- One row per clinic. Stores config + knowledge base content
-- used to build the AI receptionist's system prompt.
-- ---------------------------------------------------------
create table clinic_settings (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Bright Smile Dental Clinic',
  slug text unique not null default 'bright-smile',
  timezone text not null default 'Asia/Bangkok',

  -- Contact & location
  phone text,
  emergency_phone text,
  email text,
  address text,

  -- Operating hours, stored as structured JSON
  -- e.g. {"mon":"09:00-18:00","sat":"09:00-14:00","sun":"closed"}
  hours jsonb not null default '{}'::jsonb,

  -- Knowledge base content, structured by section.
  -- e.g. {"services": "...", "pricing": "...", "policies": "...", "staff": "..."}
  knowledge_base jsonb not null default '{}'::jsonb,

  -- AI behavior config
  system_prompt_extra text,        -- optional clinic-specific tone/rules appended to base prompt
  ai_enabled boolean not null default true,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- patients
-- Patient records collected via chat or admin entry.
-- ---------------------------------------------------------
create table patients (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinic_settings(id) on delete cascade,

  full_name text not null,
  phone text,
  email text,
  dob date,
  insurance_provider text,
  notes text,

  source_channel text not null default 'web', -- 'web' | 'whatsapp' | 'line' | 'admin'

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_patients_clinic on patients (clinic_id);
create index idx_patients_phone on patients (phone);

-- ---------------------------------------------------------
-- conversations
-- One row per chat thread (per patient/channel).
-- Stores full message history as JSON array for simplicity.
-- ---------------------------------------------------------
create table conversations (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinic_settings(id) on delete cascade,
  patient_id uuid references patients(id) on delete set null,

  channel text not null default 'web',        -- 'web' | 'whatsapp' | 'line'
  channel_user_id text,                        -- external user id (wa_id, LINE userId, session id)

  status text not null default 'open',         -- 'open' | 'needs_human' | 'closed'

  -- messages: [{ "role": "user"|"assistant", "text": "...", "created_at": "..." }, ...]
  messages jsonb not null default '[]'::jsonb,

  last_message_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index idx_conversations_clinic on conversations (clinic_id);
create index idx_conversations_patient on conversations (patient_id);
create index idx_conversations_channel_user on conversations (clinic_id, channel, channel_user_id);

-- ---------------------------------------------------------
-- appointments
-- Booking requests collected by the AI receptionist, managed
-- by staff in the admin dashboard.
-- ---------------------------------------------------------
create table appointments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinic_settings(id) on delete cascade,
  patient_id uuid not null references patients(id) on delete cascade,
  conversation_id uuid references conversations(id) on delete set null,

  reason text,
  preferred_date date,
  preferred_time time,

  status text not null default 'requested',  -- 'requested' | 'confirmed' | 'completed' | 'cancelled' | 'no_show'
  staff_notes text,

  google_event_id text,  -- set once synced to Google Calendar

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_appointments_clinic on appointments (clinic_id);
create index idx_appointments_patient on appointments (patient_id);
create index idx_appointments_status on appointments (clinic_id, status);

-- ---------------------------------------------------------
-- updated_at trigger helper
-- ---------------------------------------------------------
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_clinic_settings_updated_at
  before update on clinic_settings
  for each row execute function set_updated_at();

create trigger trg_patients_updated_at
  before update on patients
  for each row execute function set_updated_at();

create trigger trg_appointments_updated_at
  before update on appointments
  for each row execute function set_updated_at();

-- ---------------------------------------------------------
-- Row Level Security
-- For a single-clinic deployment, allow anon read on
-- clinic_settings (needed by the public chat widget to build
-- the system prompt) and allow inserts on patients/
-- conversations/appointments from anon (the chat widget),
-- while writes from the admin dashboard go through an
-- authenticated role.
--
-- For multi-tenant SaaS, replace `true` checks below with
-- clinic_id = (auth.jwt() ->> 'clinic_id')::uuid
-- ---------------------------------------------------------

alter table clinic_settings enable row level security;
alter table patients enable row level security;
alter table conversations enable row level security;
alter table appointments enable row level security;

-- clinic_settings: public read (needed for the chat widget's KB)
create policy "clinic_settings_select_anon"
  on clinic_settings for select
  using (true);

-- clinic_settings: only authenticated staff can update
create policy "clinic_settings_update_authenticated"
  on clinic_settings for update
  using (auth.role() = 'authenticated');

-- patients: anon can insert (chat widget collects info)
create policy "patients_insert_anon"
  on patients for insert
  with check (true);

-- patients: anon can select own record is not safe by phone alone;
-- restrict general select to authenticated staff
create policy "patients_select_authenticated"
  on patients for select
  using (auth.role() = 'authenticated');

create policy "patients_update_authenticated"
  on patients for update
  using (auth.role() = 'authenticated');

-- conversations: anon can insert/update their own conversation
-- (matched by channel_user_id in application logic)
create policy "conversations_insert_anon"
  on conversations for insert
  with check (true);

create policy "conversations_select_anon"
  on conversations for select
  using (true);

create policy "conversations_update_anon"
  on conversations for update
  using (true);

-- appointments: anon can insert (created from chat), staff manage via authenticated
create policy "appointments_insert_anon"
  on appointments for insert
  with check (true);

create policy "appointments_select_authenticated"
  on appointments for select
  using (auth.role() = 'authenticated');

create policy "appointments_update_authenticated"
  on appointments for update
  using (auth.role() = 'authenticated');

-- ---------------------------------------------------------
-- Seed data: default clinic + knowledge base
-- ---------------------------------------------------------
insert into clinic_settings (
  name, slug, timezone, phone, emergency_phone, email, address, hours, knowledge_base
) values (
  'Bright Smile Dental Clinic',
  'bright-smile',
  'Asia/Bangkok',
  '02-123-4567',
  '081-234-5678',
  'info@brightsmiledental.example',
  '128 Sukhumvit Soi 24, Klongtoey, Bangkok 10110',
  '{
    "mon": "09:00-18:00",
    "tue": "09:00-18:00",
    "wed": "09:00-18:00",
    "thu": "09:00-18:00",
    "fri": "09:00-18:00",
    "sat": "09:00-14:00",
    "sun": "closed"
  }'::jsonb,
  '{
    "services": "General check-up & cleaning, fillings, root canal, extractions (incl. wisdom teeth), teeth whitening, crowns & bridges, dentures, braces/orthodontics (metal, ceramic, clear aligners), dental implants, pediatric dentistry, emergency care.",
    "pricing": "Check-up & cleaning: 800-1,500 THB. Composite filling: 1,000-3,000 THB per tooth. Extraction: 1,000-3,500 THB. Root canal: 5,000-15,000 THB. Teeth whitening (in-office): 5,000-12,000 THB. Implant: 35,000-60,000 THB per implant. Braces: 25,000-80,000 THB depending on type.",
    "insurance_payment": "Accepts cash, credit/debit card, bank transfer. Works with major Thai health insurance providers - bring your insurance card. Installment plans available for treatments over 20,000 THB.",
    "appointment_policy": "Arrive 10 minutes early for first visit to complete paperwork. New patients bring a government ID. Cancellations require at least 24 hours notice or a 300 THB no-show fee may apply. Walk-ins welcome but appointments are prioritized.",
    "emergency_care": "For dental emergencies during clinic hours, call the clinic directly for same-day priority slots. After-hours, call the emergency line. Knocked-out tooth: keep it moist (milk or saliva) and come in immediately.",
    "preparation": "For sedation/IV procedures, do not eat for 6 hours prior and arrange transport home. For routine cleanings/check-ups, no special preparation needed.",
    "staff": "Dr. Somchai Tanakit - General Dentistry, 15 years experience. Dr. Apinya Wongsawat - Orthodontics & Pediatric Dentistry. Dr. Michael Chen - Oral Surgery & Implants.",
    "parking_access": "Free parking in the building basement (validate ticket at front desk). BTS Sukhumvit station, Exit 4, 5-minute walk."
  }'::jsonb
);

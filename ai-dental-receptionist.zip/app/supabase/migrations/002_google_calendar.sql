-- =========================================================
-- Migration: Google Calendar integration
-- =========================================================

-- Store OAuth tokens + calendar selection per clinic.
-- Tokens should be encrypted at rest — see note below on
-- using Supabase Vault or pgsodium for production.
alter table clinic_settings
  add column google_calendar_id text,           -- e.g. "primary" or a dedicated calendar's id
  add column google_refresh_token text,         -- encrypted in production (see notes)
  add column google_access_token text,          -- short-lived, refreshed on demand
  add column google_token_expires_at timestamptz,
  add column google_connected boolean not null default false;

-- Track calendar event linkage + sync status on appointments.
alter table appointments
  add column calendar_sync_status text not null default 'pending';
  -- 'pending' | 'synced' | 'failed' | 'not_applicable'

-- Helpful index for the follow-up/reminder job later (priority #6)
create index idx_appointments_preferred_date on appointments (clinic_id, preferred_date);

-- ---------------------------------------------------------
-- Notes on token security:
-- For production, do NOT store google_refresh_token as plain
-- text in a column readable by the anon/authenticated roles.
-- Options:
--   1. Use Supabase Vault (pgsodium) to encrypt the column,
--      decrypt only inside Edge Functions using the service role.
--   2. Store tokens in a separate table with RLS that denies
--      all access except the service role (used only by
--      Edge Functions, never exposed to the frontend).
-- The migration below shows option 2 — a locked-down table —
-- which is simpler to reason about than column-level encryption.
-- ---------------------------------------------------------

create table clinic_google_tokens (
  clinic_id uuid primary key references clinic_settings(id) on delete cascade,
  refresh_token text not null,
  access_token text,
  access_token_expires_at timestamptz,
  calendar_id text not null default 'primary',
  scope text,
  updated_at timestamptz not null default now()
);

alter table clinic_google_tokens enable row level security;

-- No policies = no access for anon/authenticated roles.
-- Only the service role (used server-side in Edge Functions)
-- bypasses RLS and can read/write this table.

create trigger trg_clinic_google_tokens_updated_at
  before update on clinic_google_tokens
  for each row execute function set_updated_at();

-- Drop the plain-text token columns added above in favor of
-- the locked-down table — keep google_calendar_id and
-- google_connected as a quick-check flag on clinic_settings.
alter table clinic_settings
  drop column google_refresh_token,
  drop column google_access_token,
  drop column google_token_expires_at;

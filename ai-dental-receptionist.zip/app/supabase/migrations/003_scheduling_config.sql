-- =========================================================
-- Migration: scheduling configuration
-- =========================================================

alter table clinic_settings
  add column slot_duration_minutes int not null default 30,
  add column booking_horizon_days int not null default 14,  -- how far ahead patients can book
  add column buffer_minutes int not null default 0;          -- gap between appointments

-- Index to speed up "find appointments on date X for clinic Y" lookups
-- used by the availability function alongside Google Calendar freebusy.
create index if not exists idx_appointments_clinic_date_status
  on appointments (clinic_id, preferred_date, status);

-- =========================================================
-- Migration: channel configurations (WhatsApp, LINE)
-- =========================================================

-- Stores per-clinic credentials for messaging channels.
-- Locked down like clinic_google_tokens — no RLS policies means
-- only the service role (Edge Functions) can read/write this table.
create table channel_configs (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinic_settings(id) on delete cascade,
  channel text not null,              -- 'whatsapp' | 'line'

  -- WhatsApp (Meta Cloud API)
  whatsapp_phone_number_id text,
  whatsapp_access_token text,
  whatsapp_business_account_id text,
  whatsapp_verify_token text,         -- used to verify webhook subscription

  -- LINE (Messaging API)
  line_channel_id text,
  line_channel_secret text,
  line_channel_access_token text,

  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique (clinic_id, channel)
);

alter table channel_configs enable row level security;
-- No policies = service role only.

create trigger trg_channel_configs_updated_at
  before update on channel_configs
  for each row execute function set_updated_at();

-- Index used by webhook handlers to look up which clinic owns an
-- incoming message based on the receiving phone_number_id / channel_id.
create index idx_channel_configs_whatsapp_phone
  on channel_configs (whatsapp_phone_number_id)
  where channel = 'whatsapp';

create index idx_channel_configs_line_channel
  on channel_configs (line_channel_id)
  where channel = 'line';

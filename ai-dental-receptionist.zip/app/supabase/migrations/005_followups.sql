-- =========================================================
-- Migration: follow-up automation
-- =========================================================

-- Tracks scheduled/sent follow-ups so the cron job never double-sends.
create table follow_ups (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinic_settings(id) on delete cascade,
  appointment_id uuid references appointments(id) on delete cascade,
  patient_id uuid not null references patients(id) on delete cascade,

  type text not null,
  -- 'appointment_reminder_24h' | 'appointment_reminder_2h'
  -- | 'booking_no_response' | 'post_visit_followup'

  channel text not null,           -- 'whatsapp' | 'line' | 'web' (web = no-op, logged only)
  status text not null default 'pending',  -- 'pending' | 'sent' | 'failed' | 'skipped'
  scheduled_for timestamptz not null,
  sent_at timestamptz,
  error text,

  created_at timestamptz not null default now(),

  unique (appointment_id, type)
);

create index idx_follow_ups_pending
  on follow_ups (scheduled_for)
  where status = 'pending';

create index idx_follow_ups_clinic on follow_ups (clinic_id);

alter table follow_ups enable row level security;
-- Service role only (no policies) — managed entirely by the cron job
-- and conversation-engine.

-- ---------------------------------------------------------
-- Follow-up configuration per clinic
-- ---------------------------------------------------------
alter table clinic_settings
  add column followups_enabled boolean not null default true,
  add column reminder_24h_enabled boolean not null default true,
  add column reminder_2h_enabled boolean not null default false,
  add column no_response_followup_enabled boolean not null default true,
  add column no_response_followup_hours int not null default 24;

-- ---------------------------------------------------------
-- pg_cron schedule
-- Requires the pg_cron extension (enabled by default on most
-- Supabase projects under Database > Extensions).
-- This calls the process-followups Edge Function every 15 minutes.
-- Replace <project-ref> and <anon-or-service-key> after deploying the
-- function — pg_cron needs an HTTP call via pg_net.
-- ---------------------------------------------------------

create extension if not exists pg_net;

-- NOTE: run this manually after deploying the Edge Function and setting
-- the actual project URL + service role key, since pg_cron jobs are
-- stored as SQL strings and can't reference secrets directly.
--
-- select cron.schedule(
--   'process-followups-every-15-min',
--   '*/15 * * * *',
--   $$
--   select net.http_post(
--     url := 'https://<project-ref>.functions.supabase.co/process-followups',
--     headers := jsonb_build_object(
--       'Content-Type', 'application/json',
--       'Authorization', 'Bearer <service-role-key>'
--     ),
--     body := '{}'::jsonb
--   );
--   $$
-- );
